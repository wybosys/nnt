//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by voiceprint.rc
//
#define ID_SEPARATOR                    0
#define VS_VERSION_INFO                 1
#define IDC_TEXTOUT                     101
#define ID_MFCLOC_MANIFEST              1000
#define AFX_IDC_FONTPROP                1000
#define IDC_WRITE                       1001
#define AFX_IDC_FONTNAMES               1001
#define IDC_SEND                        1002
#define AFX_IDC_FONTSTYLES              1002
#define IDC_CLOSE                       1003
#define AFX_IDC_FONTSIZES               1003
#define IDC_RTEXTOUT                    1004
#define IDC_WTEXTOUT                    1005
#define WM_RECORD_BEG                  1006
#define IDC_GMM_NUM                     1006
#define WM_RECORD_END                  1007
#define IDC_IDENTIFY_NUM                1007
#define IDC_PLAY_BEG                    1008
#define IDC_M_NUM                       1008
#define IDC_PLAY_END                    1009
#define IDC_COPYRIGHT                   1010
#define IDC_SECMODE                     1011
#define IDC_NORMALMODE                  1012
#define IDC_SEND_FILE                   1013
#define IDC_EXCHANGE_KEY                1014
#define IDC_CONNECT                     1015
#define WM_VOICE_STOP                  1016
#define IDC_CLEAR_TEXT                  1016
#define IDC_BUILD_GMM                   1017
#define IDC_VOICE_STOP                    1018
#define WM_BUILD_GMM                    1019
#define IDC_IMPORT_GMM                1019
#define IDC_IDENTIFY                    1020
#define IDC_EXPORT_GMM                  1021
#define IDC_RESET                       1022

// �����ڲ˵�
#define IDM_APP_EXIT         1016
#define IDM_OPTION           1017
#define IDM_APP_HELP        1018
#define IDM_APP_ABOUT    1019
// ����ͼ��
#define IDI_APP_ICON          1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
